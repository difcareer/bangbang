package com.example.empty;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           /Users/andr0day/Knife/bangbang/1.jar
 * Qualified Name:     com.example.empty.BuildConfig
 * JD-Core Version:    0.6.2
 */