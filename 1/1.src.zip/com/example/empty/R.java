package com.example.empty;

public final class R
{
  public static final class attr
  {
  }

  public static final class layout
  {
    public static final int main = 2130837504;
  }

  public static final class string
  {
    public static final int app_name = 2130903040;
  }
}

/* Location:           /Users/andr0day/Knife/bangbang/1.jar
 * Qualified Name:     com.example.empty.R
 * JD-Core Version:    0.6.2
 */