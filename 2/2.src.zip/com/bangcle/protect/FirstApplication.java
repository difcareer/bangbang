package com.bangcle.protect;

import android.app.Application;

public class FirstApplication extends Application
{
  public void onCreate()
  {
    super.onCreate();
  }
}

/* Location:           /Users/andr0day/Knife/bangbang/2.jar
 * Qualified Name:     com.bangcle.protect.FirstApplication
 * JD-Core Version:    0.6.2
 */